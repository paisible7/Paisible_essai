const wrapper = document.querySelector('.wrapper');
const signUpLink = document.querySelector('.signUp-link');
const signInLink = document.querySelector('.signIn-link');
const pwdForgot = document.getElementById('forgot-pass');

signUpLink.addEventListener('click', () => {
    wrapper.classList.add('animate-signIn');
    wrapper.classList.remove('animate-signUp');
    wrapper.classList.remove('animate-pwd'); 
});

signInLink.addEventListener('click', () => {
    wrapper.classList.add('animate-signUp');
    wrapper.classList.remove('animate-signIn');
    wrapper.classList.remove('animate-pwd'); 
});

pwdForgot.addEventListener('click', () => {
	wrapper.classList.add('animate-signIn');
    wrapper.classList.add('animate-pwd');
	wrapper.classList.remove('animate-signIn');
	wrapper.classList.remove('animate-signUp');
});
